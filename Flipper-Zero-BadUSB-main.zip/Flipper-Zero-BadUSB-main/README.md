<div align=center>

# 💀 BadUSB 💀

<p align="center">
      <a href="https://github.com/sponsors/I-Am-Jakoby">
        <img src=https://github.com/I-Am-Jakoby/I-Am-Jakoby/blob/main/img/Discord-Sponsor.png width="125" alt="Python" />
      </a>	
</p>

Subscribing to my YouTube would also be greatly appreciated. 

[<img src="https://custom-icon-badges.herokuapp.com/badge/-Subscribe-red?style=for-the-badge&logo=video&logoColor=white"/>](https://jakoby.lol/yno)

<img src= https://github.com/I-Am-Jakoby/I-Am-Jakoby/raw/main/img/disclaimer.png width="600" alt="C#" />
</div>                 

# Table of Contents

[Description](#Description)

[The Payloads](#The-Payloads)

[Contact](#Contact)

[Acknowledgments](#Acknowledgments)



# Unleash the power of your Flipper 🤓💻

***  

## Description 


🥇 I am in 1st place for most payloads submitted to Hak5❗ 

🔓 I have taken my colllection of payloads and formatted them to work for the Flipper for all of you to use❗

⚠️ Please ENJOY and use RESPONSIBLY❗ 

![hak 5](https://github.com/I-Am-Jakoby/I-Am-Jakoby/raw/main/img/hak5-banner.png)

## The Payloads 

This repository has been optimized to facilitate plug and play functionality. 

I purchased the domain `jakoby.lol` for the sole purpose of creating my own short URLs.

I did this with the intention of making room for Discord webhooks and Dropbox tokens to fit in my one-liners.

This, in turn, makes it so the user no longer needs to host their own version of the script.


| Payloads                                                                                                        | Description                                                                                       | Plug'n'Play | Author      |
| :-------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------ | :-----------| :-----------|
| [VoiceLogger](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/VoiceLogger)                | Activates your target's microphone, converts their speech to text, and exfils it to Discord.      |✅           | Jakoby      |
| [Evil-Goose](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-EvilGoose)              | A payload that hires a goose to hack your target in real time.                                     |✅           | Jakoby      |      
| [ADV-Recon](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-ADV-Recon)               | A script used to do an advanced level of recon on the target's computer.                           |✅           | Jakoby      |      
| [AcidBurn](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-AcidBurn)                 | A script I put together to be used on your friends or foes. Prepare to be roasted.       |✅           | Jakoby      | 
| [Jump-Scare](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-JumpScare)              | Just a little jumpscare that changes the target's wallpaper.                                        |✅           | Jakoby      |
| [Jump-Scare V2](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-JumpScare-2.0)       | Just a little jumpscare that plays a video in the target's PowerShell console.                      |✅           | Jakoby      |
| [ADV-RickRoll](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-ADV-RickRoll)         | RickRoll that plays in the PowerShell console after a mouse movement is detected.                    |✅           | Jakoby      |
| [PineApple](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-PineApple)               | Connect a target's PC to your WiFi PineApple.                                                       |⛔           | Jakoby      |
| [Play-WAV](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-Play-WAV)                 | Download a WAV file and play it after a mouse movement is detected.                                |✅           | Jakoby      |
| [Rage-Pop-Ups](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-Rage-PopUps)          | Generates an infinite loop of insulting pop-ups.                                                   |⛔           | Jakoby      |
| [Subscribe](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-Subscribe)               | Used to make your target subscribe to your YouTube channel.                                        |✅           | Jakoby      |       
| [Must Sub](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-MustSub)                  | A script used to make your target subscribe to 15 of Jakoby's favorite YouTube channels.                   |✅           | Jakoby      |
| [PS-Draw](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-PS-Draw)                   | A script used to generate and draw images in the PowerShell window.                                |⛔           | Jakoby      |
| [WallPaper-Troll](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-Wallpaper-Troll)   | Collects sensitive info from your target and displays it as their wallpaper to taunt them.                 |✅           | Jakoby      |
| [WallPaper-URL](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-WallPaper-URL)       | Sets the target's wallpaper to an image you provide via a URL after a mouse movement is detected.          |✅           | Jakoby      |
| [We-Found-You](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-We-Found-You)         | Opens a map with your target's current location on it.                                               |✅           | Jakoby      |
| [YT-Tripwire](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-YT-Tripwire) | Opens any YouTube video after a mouse movement is detected.                                         |✅           | Jakoby      |
| [Credz-Plz](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-Credz-Plz)               | A script used to prompt the target to enter their credentials to later be exfiltrated.                   |✅           | Jakoby      |
| [Shortcut Jacker](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-ShortcutJacker)    | A script used to embed malware in the shortcut on your target's desktop.                            |⛔           | Jakoby      |
| [Wifi Grabber](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-WifiGrabber)| Grabs your target's WiFi passwords and uploads them to either Dropbox, Discord, or both.            |✅           | Jakoby      |
| [IP Grabber](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-IP-Grabber)             | Grabs your target's IP addresses and uploads them to either Dropbox, Discord, or both.              |✅           | Jakoby      |
| [Browser Data](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB/tree/main/Payloads/Flip-BrowserData)| This payload can be used to retrieve the browsing history and bookmarks of your target.            |✅           | Jakoby      |

<!-- CONTACT -->
## Contact

<h2 align="center">📱 My Socials 📱</h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://youtube.com/c/IamJakoby?sub_confirmation=1">
        <img src=https://github.com/I-Am-Jakoby/I-Am-Jakoby/blob/main/img/youtube-svgrepo-com.svg width="48" height="48" alt="C#" />
      </a>
      <br>YouTube
    </td>
    <td align="center" width="96">
      <a href="https://twitter.com/I_Am_Jakoby">
        <img src=https://github.com/I-Am-Jakoby/I-Am-Jakoby/blob/main/img/twitter.png width="48" height="48" alt="Python" />
      </a>
      <br>Twitter
    </td>
    <td align="center" width="96">
      <a href="https://www.instagram.com/i_am_jakoby/">
        <img src=https://github.com/I-Am-Jakoby/I-Am-Jakoby/blob/main/img/insta.png width="48" height="48" alt="Golang" />
      </a>
      <br>Instagram
    </td>
    <td align="center" width="96">
      <a href="https://discord.gg/MYYER2ZcJF">
        <img src=https://github.com/I-Am-Jakoby/I-Am-Jakoby/blob/main/img/discord-v2-svgrepo-com.svg width="48" height="48" alt="Jsonnet" />
      </a>
      <br>Discord
    </td>
    <td align="center" width="96">
      <a href="https://www.tiktok.com/@i_am_jakoby?lang=en">
        <img src=https://github.com/I-Am-Jakoby/I-Am-Jakoby/raw/main/img/tiktok.svg width="48" height="48" alt="Jsonnet" />
      </a>
      <br>TikTok
    </td>    
  </tr>
</table>
</div>

<!-- ACKNOWLEDGMENTS -->
## Acknowledgments 

* [Hak5](https://hak5.org/)
* [Darren](https://github.com/hak5darren)
* [UberGuidoZ](https://github.com/UberGuidoZ)




<p align="right">(<a href="#top">back to top</a>)</p>

