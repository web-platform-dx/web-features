$done = New-Object -ComObject Wscript.Shell;$done.Popup("This payload has been detected by Microsoft. An updated undetected version will be released as soon as possible",10)
